﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Day2_Handson.Model;
using Day2_Handson.Filters;
using Microsoft.AspNetCore.Http;


// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Day2_Handson.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeesController : ControllerBase
    {



            private Employee[] emp = new Employee[]
           {
            new Employee { Id=1 , Name="Pavan" , Salary=90000 , Permanent=true, Department="CDE",Skills="Dotnet" ,DateOfBirth=new DateTime(2000,02,04) },
             new Employee { Id=2 , Name="uday" , Salary=90000 , Permanent=true, Department="AI",Skills="java" ,DateOfBirth=new DateTime(1999,01,09) } ,
            new Employee { Id=3 , Name="manoj" , Salary=90000 , Permanent=false, Department="ML",Skills="python" ,DateOfBirth=new DateTime(2000,04,08) } ,


           };


            private IEnumerable<Employee> GetStandardEmployeeList()
            {
                return emp;
            }



        // GET: api/<EmployeesController1>
        [CustomAuthFilter]
        [HttpGet]
            public IEnumerable<Employee> Get()
            {
            return GetStandardEmployeeList();
            }

        // GET api/<EmployeesController1>/5
        [HttpGet("{id}")]
            [ProducesResponseType(StatusCodes.Status200OK)]
            [ProducesResponseType(StatusCodes.Status404NotFound)]
            public IActionResult GetById(int id)
            {
                var prod = emp.FirstOrDefault((p) => p.Id == id);
                if (prod == null)
                {
                    return NotFound();
                }
                return Ok(prod);
            }

            // POST api/<EmployeesController1>
            [HttpPost]
            public void Post([FromBody] string value)
            {
            }

            // PUT api/<EmployeesController1>/5
            [HttpPut("{id}")]
            public void Put(int id, [FromBody] string value)
            {
            }

            // DELETE api/<EmployeesController1>/5
            [HttpDelete("{id}")]
            public void Delete(int id)
            {
            }
        }
    
    
}
