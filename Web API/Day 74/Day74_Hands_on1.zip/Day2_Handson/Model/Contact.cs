﻿using Microsoft.OpenApi.Models;
using System;

namespace Day2_Handson
{
    internal class Contact : OpenApiContact
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public Uri Url { get; set; }
    }
}