﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Day2_Handson.Model;
using Day2_Handson.Filters;
using Microsoft.AspNetCore.Http;


// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Day2_Handson.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeesController : ControllerBase
    {



        private List<Employee> Employees;
        public EmployeesController()
        {
            Employees = new List<Employee>()
            {
                new Employee() { Id= 1, Name="Pavan",Salary=90000,Permanent=true, Department= new Department( 2,"CDE") ,Skills=new List<Skill>(){ new Skill ( 1,"Python"), new Skill(3,"c#" ) }, DateOfBirth=new DateTime(2000,04,25) },
                 new Employee() { Id= 2, Name="Uday",Salary=20000,Permanent=true, Department= new Department( 2,"AI") ,Skills=new List<Skill>(){ new Skill ( 2,"Java"), new Skill(1,"Python" ) }, DateOfBirth=new DateTime(2000,04,02) }


            };
        }

        private List<Employee> GetStandardEmployeeList()
        {
            return Employees;
        }

        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IEnumerable<Employee> Get()
        {
            return GetStandardEmployeeList();
        }


        [HttpGet("Employee/getstandard")]
        public ActionResult<Employee> GetStandard()
        {
            return Employees.Where(i => i.Permanent == true).FirstOrDefault();
        }


        // GET api/<EmployeeController>/5
        [HttpGet("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public IActionResult GetById(int id)
        {
            var prod = Employees.FirstOrDefault((p) => p.Id == id);
            if (prod == null)
            {
                return NotFound();
            }
            return Ok(prod);
        }

        // POST api/<EmployeeController>
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }
        // PUT api/<EmployeeController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<EmployeeController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }

    }


}
