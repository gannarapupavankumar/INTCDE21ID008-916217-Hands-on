﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Day2_Handson.Model
{
    public class Department
    {
        public Department()
        { }
        public Department(int DepID, string DepName)
        {
            this.DepID = DepID;
            this.DepName = DepName;
        }
        public int DepID { get; set; }
        public string DepName { get; set; }

    }
}
