﻿using Microsoft.OpenApi.Models;
using System;

namespace Day2_Handson
{
    internal class License : OpenApiLicense
    {
        public string Name { get; set; }
        public Uri Url { get; set; }
    }
}