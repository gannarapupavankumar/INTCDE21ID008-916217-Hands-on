﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Day2_Handson.Model
{
    public class Skill
    {
        public Skill() { }
        public Skill(int skillID, string skillName)
        {
            this.SkillID = skillID;
            this.SkillName = skillName;
        }
        public int SkillID { get; set; }
        public string SkillName { get; set; }

    }
}
