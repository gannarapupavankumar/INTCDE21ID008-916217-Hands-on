﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Day2_Handson.Model;

namespace Day2_Handson
{
    public class Employee
    {
        /* public int Id { get; set; }
         public string Name { get; set; }
         public int Salary { get; set; }
         public bool Permanent { get; set; }
         public Department Department { get; set; }
         public List<Skill> Skills { get; set; }

         public DateTime DateOfBirth { get; set; }*/
        public int Id { get; set; }
        public string Name { get; set; }
    }
}

