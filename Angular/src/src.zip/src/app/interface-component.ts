export interface Employee {
    ID:number;
    Name:string;
    Salary:number;
    skill:skill[];
}

export interface Department{
    ID:number;
    Name:string;
    Salary:number;
    Permenant:boolean;
    Departmentid:number;
    Departmentname:string; 
    // skill:Skill[];
}

export interface skill{
    id:number;
    name:string;
    }

export class Employee implements Department{
   
    ID: number;
    Name: string;
    Salary: number;
    Permenant: boolean;
    Departmentid: number;
    Departmentname: string;
    
   
    constructor(id:number, name:string, salary:number, permanent:boolean,deptid:number,deptname:string){
    this.ID = id;
    this.Name = name;
    this.Salary = salary;
    this.Permenant = permanent;
    this.Departmentid=deptid;
    this.Departmentname=deptname;
    }
    
   
    }




