import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewemps',
  templateUrl: './viewemps.component.html'
})
export class ViewempsComponent {
  public Id:number=1;
  public Name:string="John";
  public Salary:number=10000;

  public Permanent:boolean=true;

  public Department_Id:number=1;
  public Department_Name:string="payroll";

  public Skills:string[]=["Html","Css","JavaScripts"];

  public DateofBirth:Date=new Date('12/31/2000');

}
