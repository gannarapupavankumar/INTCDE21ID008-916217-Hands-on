import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EditempComponent} from './editemp/editemp.component';
// , EditEmpReactiveComponent
import { QuantityIncrementComponent } from './quantity-increment/quantity-increment.component';
import { ViewempsComponent } from './viewemps/viewemps.component';
import {Routes,RouterModule} from '@angular/router'
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { EmpInfoComponent } from './emp-info/emp-info.component';
import { UserComponent } from './user/user.component';
import { HttpClientModule } from '@angular/common/http';


const appRoutes:Routes=[{path:"" , component:ViewempsComponent},
  {path:"EditEmployees" ,
  component:EditempComponent},{path:"QuantityIncrement",component:QuantityIncrementComponent},{ path: 'edit-emp-reactive/:id', component: EmployeeListComponent}
  ,{path:"User",component:UserComponent}]
  

@NgModule({
  declarations: [
    AppComponent,
    ViewempsComponent,
     EditempComponent,
    EmployeeListComponent,
    EmpInfoComponent,
    UserComponent,
    // EditEmpReactiveComponent,
    QuantityIncrementComponent,

  ],
  imports: [
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(appRoutes)

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
