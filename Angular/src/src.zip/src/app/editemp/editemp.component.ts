import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editemp',
  templateUrl: './editemp.component.html'
})

export class EditempComponent{
  public employees:string;
  public myname:string;

  constructor() { 
    this.employees = "";
    this.myname="";
  }
  
  public emp:employee={Id:1,Name:"John",Salary:10000,Permanent:false, Dept:{Id:1,Name:"Payroll"},skills:[{id:1,Name:"html"},{id:2,Name:"Css"},{id:3,Name:"Javascript"}]};
  public departmentslist:any[]=[{Id:1,Name:"Payroll"},{Id:2,Name:"Internal"},{Id:3,Name:"Hr"}];
  public OnSubmit():void{
    console.log(this.emp);
  }
}

class employee{
  public Id:number=0;
  public Name:string="";
  public Salary:number=0;
  public Permanent:boolean=true;
  public Dept:Department={Id:1,Name:"Payroll"};
  public skills:any[]=[{}];
} 

class Department{
  public Id:number=1;
  public Name:string="";
}

// import { Component, OnInit } from '@angular/core';
// import {FormGroup,FormControl,Validators} from '@angular/forms';

// @Component({
//   selector: 'app-edit-emp-reactive',
//   templateUrl: './edit-emp-reactive.component.html'
// })
// export class EditEmpReactiveComponent{
//   public emp:employee={Id:1,Name:"John",Salary:10000,Permanent:false, Dept:{Id:1,Name:"Payroll"},skills:[{id:1,Name:"html"},{id:2,Name:"Css"},{id:3,Name:"Javascript"}]};
//   public departmentslist:any[]=[{Id:1,Name:"Payroll"},{Id:2,Name:"Internal"},{Id:3,Name:"Hr"}];
  
//   Name=new FormControl('John');
//   public empForm:FormGroup = new FormGroup({

//     'name': new FormControl(this.emp.Name, [
    
//     Validators.required,
    
//     Validators.minLength(4),
    
//     Validators.maxLength(20)
    
//     ])
    
//     });

//     public deptF:FormGroup = new FormGroup({

//       'department': new FormControl("")
      
//       });

// }
// class employee{
//   public Id:number=0;
//   public Name:string="";
//   public Salary:number=0;
//   public Permanent:boolean=true;
//   public Dept:Department={Id:1,Name:"Payroll"};
//   public skills:any[]=[{}];
// } 
// class Department{
//   public Id:number=1;
//   public Name:string="";
// }

