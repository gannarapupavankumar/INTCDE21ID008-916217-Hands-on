import { Component } from '@angular/core';

import { Employee,Department} from './interface-component';

@Component({
  selector: 'app-root',
 templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],

})


export class AppComponent {
//   title = 'Favorite Movie:';
//   // heading='Employee Details';
 
// public  emp1 = new Employee(3, "John", 10000, true,1,"Payroll");

// Permanent:boolean=true;
//    Skills:string[]=["Html","Css","JavaScripts"];
//     DateofBirth:Date=new Date('12/31/2000');
    
}
